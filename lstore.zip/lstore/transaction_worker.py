import threading

class TransactionWorker:
    """
    # Creates a transaction worker object.
    """
    def __init__(self, transactions=[]):
        self.transactions = transactions  
        self.stats = []
        self.result = 0  

    """
    Appends t to transactions
    """
    def add_transaction(self, t):
        self.transactions.append(t)

    """
    Runs all transaction as a thread
    """
    def run(self):
        for transaction in self.transactions:
            success = transaction.run()
            self.stats.append(success)

        self.result = sum(1 for x in self.stats if x)
        # self.thread = threading.Thread(target=self.__run)  
        # self.thread.start()

    # """
    # Waits for the worker to finish
    # """
    # def join(self):
    #     if self.thread:
    #         self.thread.join()

    # def __run(self):
    #     for transaction in self.transactions:
    #         # each transaction returns True if committed or False if aborted
    #         self.stats.append(transaction.run())
    #     # stores the number of transactions that committed
    #     self.result = len(list(filter(lambda x: x, self.stats)))

    def join(self):
        pass